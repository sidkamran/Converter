const select_1 = document.getElementById("base1");
const select_2 = document.getElementById("base2");
const swap = document.getElementById("swap");
const input = document.getElementById("inputxt");
const converterbtn = document.getElementById("convert");
const output= document.getElementById("result");


swap.onclick=()=>{
    const temp1_value=select_1.value
    const temp2_value=select_2.value

    select_1.value=temp2_value;
    select_2.value=temp1_value;
}



function convert(){
    if(input.value==""){
        output.innerText="Please enter the value";
        output.style.color="red"
    }
    else if(select_1.value===select_2.value){
        output.innerText=input.value;
    }
    else if(select_1.value=="Decimal" && select_2.value=="Hexadecimal"){
        let number=parseInt(input.value);
        let str=number.toString(16);
        output.innerText=str;
    }
    else if(select_1.value=="Decimal" && select_2.value=="Octal"){
        let number=parseInt(input.value);
        let str=number.toString(8);
        output.innerText=str;
    }
    else if(select_1.value=="Decimal" && select_2.value=="Binary"){
        let number=parseInt(input.value);
        let str=number.toString(2);
        output.innerText=str;
    }
    else if(select_1.value=="Hexadecimal" && select_2.value=="Decimal"){
        let number=input.value;
        let str=parseInt(number,16);
        output.innerText=str;
    }
    else if(select_1.value=="Hexadecimal" && select_2.value=="Octal"){
        let number=input.value;
        let str=parseInt(number,16).toString(8);
        output.innerText=str;
    }
    else if(select_1.value=="Hexadecimal" && select_2.value=="Binary"){
        let number=input.value;
        let str=parseInt(number,16).toString(2).padStart(8,"0");
        output.innerText=str;
    }
    else if(select_1.value=="Octal" && select_2.value=="Decimal"){
        let number=input.value;
        let str=parseInt(number,8).toString(10);
        output.innerText=str;
    }
    else if(select_1.value=="Octal" && select_2.value=="Hexadecimal"){
        let number=input.value;
        let str=parseInt(number,8).toString(16);
        output.innerText=str;
    }
    else if(select_1.value=="Octal" && select_2.value=="Binary"){
        let number=input.value;
        let str=parseInt(number,8).toString(2);
        output.innerText=str;
    }
    else if(select_1.value=="Binary" && select_2.value=="Decimal"){
        let number=input.value;
        let str=parseInt(number,2).toString(10);
        output.innerText=str;
    }
    else if(select_1.value=="Binary" && select_2.value=="Hexadecimal"){
        let number=input.value;
        let str=parseInt(number,2).toString(16);
        output.innerText=str;
    }
    else if(select_1.value=="Binary" && select_2.value=="Octal"){
        let number=input.value;
        let str=parseInt(number,2).toString(8);
        output.innerText=str;
    }
    
}